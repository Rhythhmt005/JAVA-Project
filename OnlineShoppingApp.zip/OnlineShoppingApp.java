import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/* ============================================================
 * Colors
 * - Handles all ANSI escape codes for colored console output
 * - Emojis removed as requested (kept empty constants so old
 *   references compile without affecting output)
 * ============================================================ */
class Colors {
    public static final String RESET       = "\033[0m";
    public static final String BLACK       = "\033[0;30m";
    public static final String RED         = "\033[0;31m";
    public static final String GREEN       = "\033[0;32m";
    public static final String YELLOW      = "\033[0;33m";
    public static final String BLUE        = "\033[0;34m";
    public static final String PURPLE      = "\033[0;35m";
    public static final String CYAN        = "\033[0;36m";
    public static final String WHITE       = "\033[0;37m";

    public static final String BOLD        = "\033[1m";
    public static final String BOLD_RED    = "\033[1;31m";
    public static final String BOLD_GREEN  = "\033[1;32m";
    public static final String BOLD_YELLOW = "\033[1;33m";
    public static final String BOLD_BLUE   = "\033[1;34m";
    public static final String BOLD_PURPLE = "\033[1;35m";
    public static final String BOLD_CYAN   = "\033[1;36m";
    public static final String BOLD_WHITE  = "\033[1;97m";

    public static final String BG_BLACK    = "\033[40m";
    public static final String BG_RED      = "\033[41m";
    public static final String BG_GREEN    = "\033[42m";
    public static final String BG_YELLOW   = "\033[43m";
    public static final String BG_BLUE     = "\033[44m";
    public static final String BG_PURPLE   = "\033[45m";
    public static final String BG_CYAN     = "\033[46m";
    public static final String BG_WHITE    = "\033[47m";

    public static final String UNDERLINE   = "\033[4m";
    public static final String BLINK       = "\033[5m";

    // Emojis removed intentionally (left as empty strings to keep compatibility)
    public static final String CART    = "";
    public static final String CHECK   = "";
    public static final String CROSS   = "";
    public static final String STAR    = "";
    public static final String MONEY   = "";
    public static final String PACKAGE = "";
    public static final String TAG     = "";
    public static final String SPARKLE = "";
    public static final String ARROW   = ">";
}

/* ============================================================
 * Product
 * - Represents a single product in the catalog
 * - Immutable: id, name, price cannot be changed after creation
 * ============================================================ */
class Product implements Serializable {
    private static final long serialVersionUID = 1L;

    private final int         id;
    private final String      name;
    private final BigDecimal  price;

    Product(int id, String name, double price) {
        if (id <= 0) {
            throw new IllegalArgumentException("Product ID must be positive");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Product name cannot be empty");
        }
        if (price < 0) {
            throw new IllegalArgumentException("Price cannot be negative");
        }

        this.id    = id;
        this.name  = name;
        this.price = BigDecimal.valueOf(price).setScale(2, RoundingMode.HALF_UP);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Product)) return false;

        Product other = (Product) o;
        return id == other.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        // Do not change content of this formatted string (affects output layout)
        return String.format(
                "%s%d.%s %s%s%s - %s$%.2f%s",
                Colors.BOLD_CYAN, id, Colors.RESET,
                Colors.BOLD_WHITE, name, Colors.RESET,
                Colors.BOLD_GREEN, price, Colors.RESET
        );
    }
}

/* ============================================================
 * CartItem
 * - One line in the cart: a product + quantity
 * ============================================================ */
class CartItem implements Serializable {
    private static final long serialVersionUID = 1L;

    private final Product product;
    private int           quantity;

    CartItem(Product product, int quantity) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }

        this.product  = product;
        this.quantity = quantity;
    }

    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    void addQuantity(int amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
        this.quantity += amount;
    }

    BigDecimal getTotalPrice() {
        return product.getPrice().multiply(BigDecimal.valueOf(quantity));
    }

    @Override
    public String toString() {
        // Keep exact text / spacing for output layout
        return String.format(
                "  %s%s%s × %s%d%s = %s$%.2f%s",
                Colors.BOLD_WHITE, product.getName(), Colors.RESET,
                Colors.BOLD_YELLOW, quantity, Colors.RESET,
                Colors.BOLD_GREEN, getTotalPrice(), Colors.RESET
        );
    }
}

/* ============================================================
 * ShoppingCart
 * - Holds multiple CartItem objects
 * - Handles subtotal, tax, discount, and display of cart
 * ============================================================ */
class ShoppingCart implements Serializable {
    private static final long serialVersionUID = 1L;

    private final Map<Integer, CartItem> items = new HashMap<>();

    private static final BigDecimal DISCOUNT_THRESHOLD = BigDecimal.valueOf(500);
    private static final BigDecimal DISCOUNT_RATE      = BigDecimal.valueOf(0.10);
    private static final BigDecimal TAX_RATE           = BigDecimal.valueOf(0.08);

    /* ---------------- Core operations ---------------- */

    void addItem(Product product, int quantity) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }

        items.compute(product.getId(), (id, existingItem) -> {
            if (existingItem == null) {
                return new CartItem(product, quantity);
            }
            existingItem.addQuantity(quantity);
            return existingItem;
        });
    }

    boolean removeItem(int productId) {
        return items.remove(productId) != null;
    }

    void clearCart() {
        items.clear();
    }

    boolean isEmpty() {
        return items.isEmpty();
    }

    int getItemCount() {
        return items.values()
                    .stream()
                    .mapToInt(CartItem::getQuantity)
                    .sum();
    }

    Collection<CartItem> getItems() {
        return items.values();
    }

    /* ---------------- Display helpers ---------------- */

    void displayCart() {
        if (isEmpty()) {
            System.out.println("\n" + Colors.YELLOW + "Your cart is empty." + Colors.RESET);
            return;
        }

        System.out.println();
        System.out.println(Colors.BOLD_CYAN + "╔" + "═".repeat(58) + "╗" + Colors.RESET);

        String title = " CART CONTENTS ";
        System.out.println(
                Colors.BOLD_CYAN + "║" + Colors.RESET +
                Colors.BOLD_WHITE + center(title, 58) + Colors.RESET +
                Colors.BOLD_CYAN + "║" + Colors.RESET
        );

        System.out.println(Colors.BOLD_CYAN + "╠" + "═".repeat(58) + "╣" + Colors.RESET);

        items.values().forEach(System.out::println);

        System.out.println(Colors.BOLD_CYAN + "╠" + "═".repeat(58) + "╣" + Colors.RESET);

        BigDecimal subtotal = calculateSubtotal();
        String line = String.format("Subtotal: $%.2f", subtotal);

        System.out.println(
                Colors.BOLD_CYAN + "║" + Colors.RESET +
                "  " + Colors.BOLD_WHITE + line + Colors.RESET +
                " ".repeat(Math.max(0, 58 - 2 - line.length() - 2)) +
                Colors.BOLD_CYAN + "║" + Colors.RESET
        );

        System.out.println(Colors.BOLD_CYAN + "╚" + "═".repeat(58) + "╝" + Colors.RESET);
    }

    /* ---------------- Calculations ---------------- */

    BigDecimal calculateSubtotal() {
        return items.values()
                    .stream()
                    .map(CartItem::getTotalPrice)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    // Catalog-level discount (for big carts, independent of offers & coupons)
    BigDecimal calculateDiscount() {
        BigDecimal subtotal = calculateSubtotal();

        if (subtotal.compareTo(DISCOUNT_THRESHOLD) >= 0) {
            return subtotal.multiply(DISCOUNT_RATE)
                           .setScale(2, RoundingMode.HALF_UP);
        }
        return BigDecimal.ZERO;
    }

    BigDecimal calculateTax() {
        BigDecimal taxableAmount = calculateSubtotal().subtract(calculateDiscount());
        return taxableAmount.multiply(TAX_RATE)
                            .setScale(2, RoundingMode.HALF_UP);
    }

    BigDecimal calculateTotal() {
        return calculateSubtotal()
                .subtract(calculateDiscount())
                .add(calculateTax())
                .setScale(2, RoundingMode.HALF_UP);
    }

    /* ---------------- Layout utility ---------------- */

    static String center(String text, int width) {
        if (text.length() >= width) return text;

        int pad   = width - text.length();
        int left  = pad / 2;
        int right = pad - left;

        return " ".repeat(left) + text + " ".repeat(right);
    }
}

/* ============================================================
 * DataManager
 * - All file handling and CSV-related helpers
 * - Persists carts, user IDs, roles, offers, coupons, purchases
 * ============================================================ */
class DataManager {

    private static final String DATA_FILE        = "userCarts.dat";
    private static final String PURCHASE_CSV     = "user_purchase_history.csv";
    private static final String USER_ID_COUNTER  = "user_id_counter.txt";
    private static final String USER_IDS_CSV     = "user_ids.csv";
    private static final String USER_ROLES_CSV   = "user_roles.csv";
    private static final String OFFERS_CSV       = "offers.csv";
    private static final String COUPONS_CSV      = "coupons.csv";

    private static final int START_ID = 100;   // first assigned will be 101

    /* ---------------- Cart persistence ---------------- */

    @SuppressWarnings("unchecked")
    public static Map<String, ShoppingCart> loadCarts() {
        File file = new File(DATA_FILE);
        if (!file.exists()) {
            return new HashMap<>();
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (Map<String, ShoppingCart>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading cart data: " + e.getMessage());
            return new HashMap<>();
        }
    }

    public static boolean saveCarts(Map<String, ShoppingCart> carts) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            oos.writeObject(carts);
            return true;
        } catch (IOException e) {
            System.err.println("Error saving cart data: " + e.getMessage());
            return false;
        }
    }

    /* ---------------- User ID helpers ---------------- */

    static Map<String, Integer> loadUserIds() {
        Map<String, Integer> map = new HashMap<>();
        Path p = Paths.get(USER_IDS_CSV);

        if (!Files.exists(p)) return map;

        try (BufferedReader br = Files.newBufferedReader(p)) {
            String line;

            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] parts = line.split(",", -1);
                if (parts.length >= 2) {
                    String name  = parts[0].trim();
                    String idStr = parts[1].trim();
                    try {
                        int id = Integer.parseInt(idStr);
                        map.put(name, id);
                    } catch (NumberFormatException ex) {
                        // skip header or malformed lines
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading user_ids: " + e.getMessage());
        }

        return map;
    }

    static void saveUserIds(Map<String, Integer> map) {
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(USER_IDS_CSV))) {
            for (Map.Entry<String, Integer> e : map.entrySet()) {
                bw.write(e.getKey() + "," + e.getValue());
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving user_ids: " + e.getMessage());
        }
    }

    static int readCounter() {
        Path p = Paths.get(USER_ID_COUNTER);
        if (!Files.exists(p)) return START_ID;

        try {
            String s = new String(Files.readAllBytes(p)).trim();
            if (s.isEmpty()) return START_ID;
            return Integer.parseInt(s);
        } catch (IOException | NumberFormatException e) {
            return START_ID;
        }
    }

    static void writeCounter(int val) {
        try {
            Files.write(Paths.get(USER_ID_COUNTER), String.valueOf(val).getBytes());
        } catch (IOException e) {
            System.err.println("Error writing counter: " + e.getMessage());
        }
    }

    static int getOrCreateUserId(String username, Map<String, Integer> userIds, int[] counterRef) {
        if (userIds.containsKey(username)) {
            return userIds.get(username);
        }

        int next = counterRef[0] + 1;
        counterRef[0] = next;
        userIds.put(username, next);
        return next;
    }

    /* ---------------- Role helpers ---------------- */

    static Map<String, String> loadUserRoles() {
        Map<String, String> roles = new HashMap<>();
        Path p = Paths.get(USER_ROLES_CSV);

        if (!Files.exists(p)) return roles;

        try (BufferedReader br = Files.newBufferedReader(p)) {
            String line;

            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] parts = line.split(",", -1);
                if (parts.length >= 2) {
                    roles.put(parts[0].trim(), parts[1].trim().toLowerCase());
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading user_roles: " + e.getMessage());
        }

        return roles;
    }

    static void saveUserRoles(Map<String, String> roles) {
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(USER_ROLES_CSV))) {
            for (Map.Entry<String, String> e : roles.entrySet()) {
                bw.write(e.getKey() + "," + e.getValue());
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving user_roles: " + e.getMessage());
        }
    }

    /* ---------------- Offers helpers ---------------- */
    // offers.csv format: product_id,min_qty,discount_percent,description

    static List<String> loadOffersRaw() {
        Path p = Paths.get(OFFERS_CSV);
        if (!Files.exists(p)) return new ArrayList<>();

        try {
            return Files.readAllLines(p);
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    static void saveOffersRaw(List<String> lines) {
        try {
            Files.write(Paths.get(OFFERS_CSV), lines);
        } catch (IOException e) {
            System.err.println("Error writing offers: " + e.getMessage());
        }
    }

    /* ---------------- Coupons helpers ---------------- */
    // coupons.csv: code,min_total,discount_percent,payment_method(optional)

    static List<String> loadCouponsRaw() {
        Path p = Paths.get(COUPONS_CSV);
        if (!Files.exists(p)) return new ArrayList<>();

        try {
            return Files.readAllLines(p);
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    static void saveCouponsRaw(List<String> lines) {
        try {
            Files.write(Paths.get(COUPONS_CSV), lines);
        } catch (IOException e) {
            System.err.println("Error writing coupons: " + e.getMessage());
        }
    }

    /* ---------------- Purchase export (per user) ---------------- */

    public static boolean appendPurchaseForUser(String username, ShoppingCart cart) {
        if (cart == null || cart.isEmpty()) return true;

        Map<String, Integer> userIds = loadUserIds();
        int counter = readCounter();
        int[] counterRef = new int[]{ counter };

        boolean needHeader = !Files.exists(Paths.get(PURCHASE_CSV));

        try (BufferedWriter bw = Files.newBufferedWriter(
                Paths.get(PURCHASE_CSV),
                StandardOpenOption.CREATE,
                StandardOpenOption.APPEND
        )) {
            if (needHeader) {
                bw.write("user_id,username,date,product_id,product_name,quantity,price,total_cart_value");
                bw.newLine();
            }

            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
            int uid = getOrCreateUserId(username, userIds, counterRef);

            BigDecimal totalCart = cart.calculateSubtotal().setScale(2, RoundingMode.HALF_UP);

            for (CartItem ci : cart.getItems()) {
                String line = String.format(
                        Locale.US,
                        "%d,%s,%s,%d,%s,%d,%.2f,%.2f",
                        uid,
                        username.replace(",", " "),
                        timestamp,
                        ci.getProduct().getId(),
                        ci.getProduct().getName().replace(",", " "),
                        ci.getQuantity(),
                        ci.getProduct().getPrice(),
                        totalCart
                );
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error appending purchase CSV: " + e.getMessage());
            return false;
        }

        saveUserIds(userIds);
        writeCounter(counterRef[0]);
        return true;
    }
}

/* ============================================================
 * ProductCatalog
 * - Holds and displays all available products
 * ============================================================ */
class ProductCatalog {
    private final Map<Integer, Product> products = new HashMap<>();

    void addProduct(Product product) {
        products.put(product.getId(), product);
    }

    Optional<Product> getProductById(int id) {
        return Optional.ofNullable(products.get(id));
    }

    List<Product> getProducts() {
        return new ArrayList<>(products.values());
    }

    void displayCatalog() {
        System.out.println();
        System.out.println(Colors.BOLD_BLUE + "╔" + "═".repeat(58) + "╗" + Colors.RESET);

        String title = " PRODUCT CATALOG ";
        System.out.println(
                Colors.BOLD_BLUE + "║" + Colors.RESET +
                Colors.BOLD_WHITE + ShoppingCart.center(title, 58) + Colors.RESET +
                Colors.BOLD_BLUE + "║" + Colors.RESET
        );

        System.out.println(Colors.BOLD_BLUE + "╠" + "═".repeat(58) + "╣" + Colors.RESET);

        products.values()
                .stream()
                .sorted(Comparator.comparingInt(Product::getId))
                .forEach(p -> {
                    String stripped = stripAnsi(p.toString());
                    String padding  = " ".repeat(Math.max(0, 58 - stripped.length() - 2));

                    System.out.println(
                            Colors.BOLD_BLUE + "║" + Colors.RESET +
                            "  " + p + padding +
                            Colors.BOLD_BLUE + "║" + Colors.RESET
                    );
                });

        System.out.println(Colors.BOLD_BLUE + "╚" + "═".repeat(58) + "╝" + Colors.RESET);
    }

    private static String stripAnsi(String str) {
        return str.replaceAll("\033\\[[;\\d]*m", "");
    }

    static ProductCatalog createDefaultCatalog() {
        ProductCatalog c = new ProductCatalog();
        c.addProduct(new Product(1, "Laptop",         1000.00));
        c.addProduct(new Product(2, "Phone",          500.00));
        c.addProduct(new Product(3, "Headphones",     50.00));
        c.addProduct(new Product(4, "Smartwatch",     200.00));
        c.addProduct(new Product(5, "Tablet",         350.00));
        c.addProduct(new Product(6, "Wireless Mouse", 25.00));
        return c;
    }
}

/* ============================================================
 * OnlineShoppingApp (Main)
 * - Handles roles: Admin / Employee / User
 * - Controls menus, flows, and integrates all components
 * ============================================================ */
public class OnlineShoppingApp {

    private final Scanner                 scanner;
    private final ProductCatalog          catalog;
    private final Map<String, ShoppingCart> userCarts;

    private String         currentUsername;
    private ShoppingCart   currentCart;
    private Map<String, String> userRoles;   // username -> role

    public OnlineShoppingApp() {
        this.scanner   = new Scanner(System.in);
        this.catalog   = ProductCatalog.createDefaultCatalog();
        this.userCarts = DataManager.loadCarts();
        this.userRoles = DataManager.loadUserRoles();
    }

    /* ---------------- Welcome & login ---------------- */

    private void displayWelcomeBanner() {
        System.out.println();
        System.out.println(Colors.BOLD_CYAN + "╔" + "═".repeat(58) + "╗" + Colors.RESET);
        System.out.println(Colors.BOLD_CYAN + "║" + Colors.RESET + " ".repeat(58) + Colors.BOLD_CYAN + "║" + Colors.RESET);

        String title = " WELCOME TO JAVASHOP ONLINE ";
        System.out.println(
                Colors.BOLD_CYAN + "║" + Colors.RESET +
                Colors.BOLD_WHITE + ShoppingCart.center(title, 58) + Colors.RESET +
                Colors.BOLD_CYAN + "║" + Colors.RESET
        );

        System.out.println(Colors.BOLD_CYAN + "║" + Colors.RESET + " ".repeat(58) + Colors.BOLD_CYAN + "║" + Colors.RESET);

        String subtitle = "Experience the easiest way to shop online!";
        System.out.println(
                Colors.BOLD_CYAN + "║" + Colors.RESET +
                Colors.CYAN + ShoppingCart.center(subtitle, 58) + Colors.RESET +
                Colors.BOLD_CYAN + "║" + Colors.RESET
        );

        System.out.println(Colors.BOLD_CYAN + "║" + Colors.RESET + " ".repeat(58) + Colors.BOLD_CYAN + "║" + Colors.RESET);
        System.out.println(Colors.BOLD_CYAN + "╚" + "═".repeat(58) + "╝" + Colors.RESET);
        System.out.println();
    }

    private String getUsername() {
        System.out.print(Colors.BOLD_CYAN + "Enter your username: " + Colors.RESET);
        String username = scanner.nextLine().trim();

        while (username.isEmpty()) {
            System.out.print(
                    Colors.RED + "Username cannot be empty. " + Colors.RESET +
                    Colors.BOLD_CYAN + "Please enter your username: " + Colors.RESET
            );
            username = scanner.nextLine().trim();
        }

        return username;
    }

    /**
     * Decide role for a user during login.
     * If role is stored in file, reuse it.
     * If username is "admin", auto-assign admin.
     * Otherwise, ask the user which role they want (1–3).
     */
    private String chooseRoleForLogin(String username) {
        if (userRoles.containsKey(username)) {
            String existing = userRoles.get(username);
            System.out.println(
                    Colors.BOLD_GREEN + "Detected role for " + username + ": " +
                    existing.toUpperCase() + Colors.RESET
            );
            return existing;
        }

        if ("admin".equalsIgnoreCase(username)) {
            userRoles.put(username, "admin");
            DataManager.saveUserRoles(userRoles);
            System.out.println(Colors.BOLD_GREEN + "Logging in as ADMIN." + Colors.RESET);
            return "admin";
        }

        System.out.println();
        System.out.println(Colors.BOLD_PURPLE + "Login as which role?" + Colors.RESET);
        System.out.println("  1. Admin");
        System.out.println("  2. Employee");
        System.out.println("  3. User");

        int choice;
        while (true) {
            choice = getIntInput("Choose (1-3): ");
            if (choice >= 1 && choice <= 3) break;
            System.out.println(Colors.RED + "Invalid choice. Enter 1, 2 or 3." + Colors.RESET);
        }

        String role = switch (choice) {
            case 1 -> "admin";
            case 2 -> "employee";
            default -> "user";
        };

        userRoles.put(username, role);
        DataManager.saveUserRoles(userRoles);

        System.out.println(
                Colors.BOLD_GREEN +
                "Role set to " + role.toUpperCase() + " for " + username +
                Colors.RESET
        );

        return role;
    }

    private void switchUser(String username) {
        currentUsername = username;
        currentCart     = userCarts.computeIfAbsent(username, k -> new ShoppingCart());

        System.out.println();
        System.out.println(
                Colors.BOLD_GREEN + "Welcome, " +
                Colors.BOLD_YELLOW + username +
                Colors.BOLD_GREEN + "!" + Colors.RESET
        );

        if (!currentCart.isEmpty()) {
            System.out.println(
                    Colors.CYAN + "You have " +
                    Colors.BOLD_WHITE + currentCart.getItemCount() +
                    Colors.CYAN + " item(s) in your cart." + Colors.RESET
            );
        }
    }

    /* ---------------- Menu rendering ---------------- */

    private void displayMainMenuForRole(String role) {
        System.out.println();
        System.out.println(Colors.BOLD_PURPLE + "╔" + "═".repeat(58) + "╗" + Colors.RESET);

        String title = " MAIN MENU (" + role.toUpperCase() + ") - User: " + currentUsername + " ";
        System.out.println(
                Colors.BOLD_PURPLE + "║" + Colors.RESET +
                Colors.BOLD_WHITE + ShoppingCart.center(title, 58) + Colors.RESET +
                Colors.BOLD_PURPLE + "║" + Colors.RESET
        );

        System.out.println(Colors.BOLD_PURPLE + "╠" + "═".repeat(58) + "╣" + Colors.RESET);

        switch (role.toLowerCase()) {
            case "admin" -> {
                System.out.println(menuLine("1. Show Catalog"));
                System.out.println(menuLine("2. Add Product to Cart"));
                System.out.println(menuLine("3. Remove Product from Cart"));
                System.out.println(menuLine("4. View Cart"));
                System.out.println(menuLine("5. Checkout"));
                System.out.println(menuLine("6. Admin Panel"));
                System.out.println(menuLine("7. Switch User"));
                System.out.println(menuLine("8. Exit"));
            }
            case "employee" -> {
                System.out.println(menuLine("1. Show Catalog"));
                System.out.println(menuLine("2. Employee Panel (offers/history)"));
                System.out.println(menuLine("3. View Price List"));
                System.out.println(menuLine("4. View Cart"));
                System.out.println(menuLine("5. Checkout (as user)"));
                System.out.println(menuLine("6. Clear Cart"));
                System.out.println(menuLine("7. Switch User"));
                System.out.println(menuLine("8. Exit"));
            }
            default -> { // user
                System.out.println(menuLine("1. Show Catalog"));
                System.out.println(menuLine("2. Add Product to Cart"));
                System.out.println(menuLine("3. Remove Product from Cart"));
                System.out.println(menuLine("4. View Cart"));
                System.out.println(menuLine("5. Checkout (apply coupons)"));
                System.out.println(menuLine("6. Clear Cart"));
                System.out.println(menuLine("7. Switch User"));
                System.out.println(menuLine("8. Exit"));
            }
        }

        System.out.println(Colors.BOLD_PURPLE + "╚" + "═".repeat(58) + "╝" + Colors.RESET);
        System.out.print(Colors.BOLD_YELLOW + "Choose an option (1-8): " + Colors.RESET);
    }

    private String menuLine(String text) {
        return Colors.BOLD_PURPLE + "║" + Colors.RESET +
               Colors.CYAN + "  " + Colors.ARROW + " " + Colors.RESET +
               text +
               " ".repeat(Math.max(0, 53 - text.length())) +
               Colors.BOLD_PURPLE + "║" + Colors.RESET;
    }

    private int getIntInput(String prompt) {
        while (true) {
            try {
                System.out.print(Colors.BOLD_CYAN + prompt + Colors.RESET);
                int value = scanner.nextInt();
                scanner.nextLine(); // consume newline
                return value;
            } catch (InputMismatchException e) {
                System.out.println(Colors.RED + "Invalid input. Please enter a number." + Colors.RESET);
                scanner.nextLine(); // clear invalid input
            }
        }
    }

    /* ---------------- Admin Panel ---------------- */

    private void adminPanel() {
        while (true) {
            System.out.println();
            System.out.println(Colors.BOLD_BLUE + "Admin Panel" + Colors.RESET);
            System.out.println("1. List users and roles");
            System.out.println("2. Grant role to user");
            System.out.println("3. Revoke role (set to user)");
            System.out.println("4. View purchase history");
            System.out.println("5. Back");

            int c = getIntInput("Choice: ");

            if (c == 1) {
                listUsersAndRoles();
            } else if (c == 2) {
                System.out.print("Enter username to grant role to: ");
                String u = scanner.nextLine().trim();

                System.out.print("Enter role (admin/employee/user): ");
                String r = scanner.nextLine().trim().toLowerCase();

                if (!r.matches("admin|employee|user")) {
                    System.out.println(Colors.RED + "Invalid role." + Colors.RESET);
                } else {
                    userRoles.put(u, r);
                    DataManager.saveUserRoles(userRoles);
                    System.out.println(Colors.BOLD_GREEN + "Granted " + r + " to " + u + Colors.RESET);
                }
            } else if (c == 3) {
                System.out.print("Enter username to revoke role (set to user): ");
                String u = scanner.nextLine().trim();

                userRoles.put(u, "user");
                DataManager.saveUserRoles(userRoles);
                System.out.println(Colors.BOLD_GREEN + "Set " + u + " to USER." + Colors.RESET);
            } else if (c == 4) {
                viewPurchaseHistory();
            } else if (c == 5) {
                break;
            } else {
                System.out.println(Colors.RED + "Invalid choice." + Colors.RESET);
            }
        }
    }

    private void listUsersAndRoles() {
        Set<String> names = new TreeSet<>();
        names.addAll(userCarts.keySet());
        names.addAll(userRoles.keySet());

        Map<String, Integer> ids = DataManager.loadUserIds();

        System.out.println();
        System.out.printf("%-15s %-10s %-8s%n", "Username", "Role", "User_ID");
        System.out.println("---------------------------------------------");

        for (String name : names) {
            String  role = userRoles.getOrDefault(name, "user");
            Integer id   = ids.get(name);

            System.out.printf(
                    "%-15s %-10s %-8s%n",
                    name,
                    role,
                    (id == null ? "-" : id)
            );
        }
    }

    /* ---------------- Employee Panel ---------------- */

    private void employeePanel() {
        while (true) {
            System.out.println();
            System.out.println(Colors.BOLD_BLUE + "Employee Panel" + Colors.RESET);
            System.out.println("1. View purchase history (CSV preview)");
            System.out.println("2. View active offers");
            System.out.println("3. Add offer");
            System.out.println("4. Remove offer (by product id)");
            System.out.println("5. Back");

            int c = getIntInput("Choice: ");

            if (c == 1) {
                viewPurchaseHistory();
            } else if (c == 2) {
                listOffers();
            } else if (c == 3) {
                addOfferInteractive();
            } else if (c == 4) {
                removeOfferInteractive();
            } else if (c == 5) {
                break;
            } else {
                System.out.println(Colors.RED + "Invalid choice." + Colors.RESET);
            }
        }
    }

    private void viewPurchaseHistory() {
        Path p = Paths.get("user_purchase_history.csv");
        if (!Files.exists(p)) {
            System.out.println(Colors.YELLOW + "No purchase history file found." + Colors.RESET);
            return;
        }

        try {
            List<String> lines = Files.readAllLines(p);
            System.out.println("\n=== Purchase history (first 200 lines) ===");
            for (int i = 0; i < Math.min(lines.size(), 200); i++) {
                System.out.println(lines.get(i));
            }
            System.out.println("=== End preview ===");
        } catch (IOException e) {
            System.err.println("Error reading purchase history: " + e.getMessage());
        }
    }

    private void listOffers() {
        List<String> lines = DataManager.loadOffersRaw();
        if (lines.isEmpty()) {
            System.out.println(Colors.YELLOW + "No offers configured." + Colors.RESET);
            return;
        }

        System.out.println("\nOffers (product_id,min_qty,discount%,description):");
        for (String l : lines) {
            System.out.println(l);
        }
    }

    private void addOfferInteractive() {
        int pid  = getIntInput("Enter product id for offer: ");
        int minq = getIntInput("Enter min quantity to activate offer: ");
        int pct  = getIntInput("Enter discount percent (e.g. 15 for 15%): ");

        System.out.print("Enter a short description: ");
        String desc = scanner.nextLine().trim().replace(",", " ");

        String row = pid + "," + minq + "," + pct + "," + desc;

        List<String> lines = DataManager.loadOffersRaw();
        lines.add(row);
        DataManager.saveOffersRaw(lines);

        System.out.println(Colors.BOLD_GREEN + "Offer added." + Colors.RESET);
    }

    private void removeOfferInteractive() {
        int pid = getIntInput("Enter product id to remove offers for: ");

        List<String> lines = DataManager.loadOffersRaw()
                .stream()
                .filter(s -> {
                    String[] parts = s.split(",", -1);
                    if (parts.length >= 1) {
                        try {
                            return Integer.parseInt(parts[0].trim()) != pid;
                        } catch (NumberFormatException e) {
                            return true;
                        }
                    }
                    return true;
                })
                .collect(Collectors.toList());

        DataManager.saveOffersRaw(lines);
        System.out.println(Colors.BOLD_GREEN + "Offers for product " + pid + " removed." + Colors.RESET);
    }

    /* ---------------- Coupons helpers ---------------- */

    private void listCoupons() {
        List<String> lines = DataManager.loadCouponsRaw();
        if (lines.isEmpty()) {
            System.out.println(Colors.YELLOW + "No coupons configured." + Colors.RESET);
            return;
        }

        System.out.println("\nCoupons (code,min_total,discount%,payment_method):");
        for (String l : lines) {
            System.out.println(l);
        }
    }

    /* ---------------- Offer and coupon application ---------------- */

    private BigDecimal applyOffersAndReturnDiscount(ShoppingCart cart) {
        List<String> offers = DataManager.loadOffersRaw();
        Map<Integer, Integer> bestPct = new HashMap<>(); // productId -> best percent

        for (String o : offers) {
            String[] p = o.split(",", -1);
            if (p.length < 3) continue;

            try {
                int pid  = Integer.parseInt(p[0].trim());
                int minq = Integer.parseInt(p[1].trim());
                int pct  = Integer.parseInt(p[2].trim());

                CartItem ci = cart.getItems()
                                  .stream()
                                  .filter(x -> x.getProduct().getId() == pid)
                                  .findFirst()
                                  .orElse(null);

                if (ci != null && ci.getQuantity() >= minq) {
                    bestPct.merge(pid, pct, Math::max);
                }
            } catch (NumberFormatException ignored) {
                // ignore bad offer lines
            }
        }

        BigDecimal discount = BigDecimal.ZERO;

        for (CartItem ci : cart.getItems()) {
            int pid = ci.getProduct().getId();

            if (bestPct.containsKey(pid)) {
                int pct = bestPct.get(pid);

                BigDecimal itemTotal = ci.getTotalPrice();
                BigDecimal itemDisc = itemTotal
                        .multiply(BigDecimal.valueOf(pct))
                        .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);

                discount = discount.add(itemDisc);
            }
        }

        return discount.setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal evaluateCoupon(String code, ShoppingCart cart, String paymentMethod) {
        List<String> coupons = DataManager.loadCouponsRaw();

        for (String line : coupons) {
            String[] p = line.split(",", -1);
            if (p.length < 3) continue;

            String ccode = p[0].trim();
            if (!ccode.equalsIgnoreCase(code)) continue;

            try {
                BigDecimal minTotal = new BigDecimal(p[1].trim());
                int pct            = Integer.parseInt(p[2].trim());
                String payMethod   = (p.length >= 4) ? p[3].trim() : "";

                if (cart.calculateSubtotal().compareTo(minTotal) < 0) {
                    return BigDecimal.ZERO;
                }

                if (!payMethod.isEmpty() && paymentMethod != null &&
                        !paymentMethod.equalsIgnoreCase(payMethod)) {
                    return BigDecimal.ZERO;
                }

                BigDecimal disc = cart.calculateSubtotal()
                                      .multiply(BigDecimal.valueOf(pct))
                                      .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);

                return disc;
            } catch (NumberFormatException ignored) {
                // ignore for malformed coupons
            }
        }

        return BigDecimal.ZERO;
    }

    /* ---------------- User checkout flow ---------------- */

    private void userCheckoutFlow() {
        if (currentCart.isEmpty()) {
            System.out.println(Colors.YELLOW + "Your cart is empty. Add some products before checkout." + Colors.RESET);
            return;
        }

        currentCart.displayCart();

        // 1. Offers
        BigDecimal offersDiscount = applyOffersAndReturnDiscount(currentCart);
        if (offersDiscount.compareTo(BigDecimal.ZERO) > 0) {
            System.out.println(Colors.BOLD_YELLOW + "Offers discount applied: -$" + offersDiscount + Colors.RESET);
        }

        // 2. Optional coupon listing
        System.out.print(Colors.BOLD_CYAN + "Do you want to see available coupons? (y/n): " + Colors.RESET);
        String see = scanner.nextLine().trim().toLowerCase();
        if (see.equals("y") || see.equals("yes")) {
            listCoupons();
        }

        // 3. Coupon input
        System.out.print(Colors.BOLD_CYAN + "Enter coupon code (or leave blank): " + Colors.RESET);
        String coupon = scanner.nextLine().trim();

        BigDecimal couponDiscount = BigDecimal.ZERO;
        if (!coupon.isEmpty()) {
            couponDiscount = evaluateCoupon(coupon, currentCart, null);
            if (couponDiscount.compareTo(BigDecimal.ZERO) > 0) {
                System.out.println(Colors.BOLD_YELLOW + "Coupon applied: -$" + couponDiscount + Colors.RESET);
            } else {
                System.out.println(Colors.RED + "Coupon not valid or conditions not met." + Colors.RESET);
            }
        }

        // 4. Totals
        BigDecimal subtotal     = currentCart.calculateSubtotal();
        BigDecimal cartDiscount = currentCart.calculateDiscount();
        BigDecimal tax          = currentCart.calculateTax();

        BigDecimal total = subtotal
                .subtract(cartDiscount)
                .subtract(offersDiscount)
                .subtract(couponDiscount)
                .add(tax)
                .setScale(2, RoundingMode.HALF_UP);

        // 5. Checkout summary (layout unchanged)
        System.out.println();
        System.out.println(Colors.BOLD_PURPLE + "╔" + "═".repeat(58) + "╗" + Colors.RESET);

        String title = " CHECKOUT SUMMARY ";
        System.out.println(
                Colors.BOLD_PURPLE + "║" + Colors.RESET +
                Colors.BOLD_WHITE + ShoppingCart.center(title, 58) + Colors.RESET +
                Colors.BOLD_PURPLE + "║" + Colors.RESET
        );

        System.out.println(Colors.BOLD_PURPLE + "╠" + "═".repeat(58) + "╣" + Colors.RESET);

        System.out.printf(
                Colors.BOLD_PURPLE + "║" + Colors.RESET +
                "  Subtotal:          %s$%.2f%s%n",
                Colors.GREEN, subtotal, Colors.RESET
        );

        if (cartDiscount.compareTo(BigDecimal.ZERO) > 0) {
            System.out.printf(
                    Colors.BOLD_PURPLE + "║" + Colors.RESET +
                    "  Discount (10%%):   %s-$%.2f%s%n",
                    Colors.BOLD_YELLOW, cartDiscount, Colors.RESET
            );
        }

        if (offersDiscount.compareTo(BigDecimal.ZERO) > 0) {
            System.out.printf(
                    Colors.BOLD_PURPLE + "║" + Colors.RESET +
                    "  Offers:            %s-$%.2f%s%n",
                    Colors.BOLD_YELLOW, offersDiscount, Colors.RESET
            );
        }

        if (couponDiscount.compareTo(BigDecimal.ZERO) > 0) {
            System.out.printf(
                    Colors.BOLD_PURPLE + "║" + Colors.RESET +
                    "  Coupon:            %s-$%.2f%s%n",
                    Colors.BOLD_YELLOW, couponDiscount, Colors.RESET
            );
        }

        System.out.printf(
                Colors.BOLD_PURPLE + "║" + Colors.RESET +
                "  Tax (8%%):          %s$%.2f%s%n",
                Colors.CYAN, tax, Colors.RESET
        );

        System.out.println(Colors.BOLD_PURPLE + "╠" + "═".repeat(58) + "╣" + Colors.RESET);

        System.out.printf(
                Colors.BOLD_PURPLE + "║" + Colors.RESET +
                "  %sTOTAL:%s           %s$%.2f%s%n",
                Colors.BOLD_WHITE, Colors.RESET,
                Colors.BOLD_GREEN, total, Colors.RESET
        );

        System.out.println(Colors.BOLD_PURPLE + "╚" + "═".repeat(58) + "╝" + Colors.RESET);

        // 6. Confirm + record purchase
        System.out.print(Colors.BOLD_CYAN + "Confirm purchase and record? (y/n): " + Colors.RESET);
        String resp = scanner.nextLine().trim().toLowerCase();

        if (resp.equals("y") || resp.equals("yes")) {
            boolean ok = DataManager.appendPurchaseForUser(currentUsername, currentCart);
            if (!ok) {
                System.out.println(Colors.RED + "Failed to record purchase." + Colors.RESET);
            } else {
                System.out.println(Colors.BOLD_GREEN + "Purchase recorded. Thank you!" + Colors.RESET);
            }

            System.out.print(Colors.BOLD_CYAN + "Clear your cart now? (y/n): " + Colors.RESET);
            String r2 = scanner.nextLine().trim().toLowerCase();

            if (r2.equals("y") || r2.equals("yes")) {
                currentCart.clearCart();
                DataManager.saveCarts(userCarts);
                System.out.println(Colors.BOLD_GREEN + "Cart cleared." + Colors.RESET);
            }
        } else {
            System.out.println(Colors.CYAN + "Purchase cancelled." + Colors.RESET);
        }
    }

    /* ---------------- Cart operations (simple flows) ---------------- */

    private void handleAddProduct() {
        int productId = getIntInput("Enter product ID: ");
        int quantity  = getIntInput("Enter quantity: ");

        if (quantity <= 0) {
            System.out.println(Colors.RED + "Quantity must be positive." + Colors.RESET);
            return;
        }

        catalog.getProductById(productId).ifPresentOrElse(
                product -> {
                    currentCart.addItem(product, quantity);
                    System.out.println(
                            Colors.BOLD_GREEN + "Added to cart: " +
                            Colors.BOLD_WHITE + product.getName() +
                            Colors.BOLD_GREEN + " × " +
                            Colors.BOLD_YELLOW + quantity + Colors.RESET
                    );
                    DataManager.saveCarts(userCarts);
                },
                () -> System.out.println(
                        Colors.RED + "Product not found. Please check the catalog." + Colors.RESET
                )
        );
    }

    private void handleRemoveProduct() {
        if (currentCart.isEmpty()) {
            System.out.println(Colors.YELLOW + "Your cart is empty. Nothing to remove." + Colors.RESET);
            return;
        }

        currentCart.displayCart();

        int productId = getIntInput("\nEnter product ID to remove: ");

        if (currentCart.removeItem(productId)) {
            System.out.println(Colors.BOLD_GREEN + "Product removed from cart." + Colors.RESET);
            DataManager.saveCarts(userCarts);
        } else {
            System.out.println(Colors.RED + "Product not found in cart." + Colors.RESET);
        }
    }

    private void handleClearCart() {
        if (currentCart.isEmpty()) {
            System.out.println(Colors.YELLOW + "Your cart is already empty." + Colors.RESET);
            return;
        }

        System.out.print(Colors.BOLD_YELLOW + "Are you sure you want to clear your cart? (y/n): " + Colors.RESET);
        String response = scanner.nextLine().trim().toLowerCase();

        if (response.equals("y") || response.equals("yes")) {
            currentCart.clearCart();
            System.out.println(Colors.BOLD_GREEN + "Cart cleared." + Colors.RESET);
            DataManager.saveCarts(userCarts);
        } else {
            System.out.println(Colors.CYAN + "Cart not cleared." + Colors.RESET);
        }
    }

    /* ---------------- Exit / Goodbye ---------------- */

    private void printGoodbyeBox() {
        System.out.println();
        System.out.println(Colors.BOLD_CYAN + "╔" + "═".repeat(58) + "╗" + Colors.RESET);

        String line1 = "Thank you for shopping at JavaShop Online!";
        String line2 = "Goodbye, " + currentUsername + "!";

        System.out.println(
                Colors.BOLD_CYAN + "║" + Colors.RESET +
                Colors.BOLD_WHITE + ShoppingCart.center(line1, 58) + Colors.RESET +
                Colors.BOLD_CYAN + "║" + Colors.RESET
        );

        System.out.println(
                Colors.BOLD_CYAN + "║" + Colors.RESET +
                Colors.BOLD_GREEN + ShoppingCart.center(line2, 58) + Colors.RESET +
                Colors.BOLD_CYAN + "║" + Colors.RESET
        );

        System.out.println(Colors.BOLD_CYAN + "╚" + "═".repeat(58) + "╝" + Colors.RESET);
        System.out.println();
    }

    /* ---------------- Main Run Loop ---------------- */

    public void run() {
        displayWelcomeBanner();

        String username = getUsername();
        String role     = chooseRoleForLogin(username);

        switchUser(username);

        boolean running = true;

        while (running) {
            displayMainMenuForRole(role);
            int choice = getIntInput("");

            try {
                switch (role.toLowerCase()) {
                    case "admin" -> {
                        switch (choice) {
                            case 1 -> catalog.displayCatalog();
                            case 2 -> handleAddProduct();
                            case 3 -> handleRemoveProduct();
                            case 4 -> currentCart.displayCart();
                            case 5 -> userCheckoutFlow();
                            case 6 -> adminPanel();
                            case 7 -> {
                                username = getUsername();
                                role     = chooseRoleForLogin(username);
                                switchUser(username);
                            }
                            case 8 -> {
                                DataManager.saveUserRoles(userRoles);
                                DataManager.saveCarts(userCarts);
                                printGoodbyeBox();
                                running = false;
                            }
                            default -> System.out.println(
                                    Colors.RED + "Invalid choice. Please select 1-8." + Colors.RESET
                            );
                        }
                    }

                    case "employee" -> {
                        switch (choice) {
                            case 1 -> catalog.displayCatalog();
                            case 2 -> employeePanel();
                            case 3 -> catalog.displayCatalog(); // price list == catalog for now
                            case 4 -> currentCart.displayCart();
                            case 5 -> userCheckoutFlow();
                            case 6 -> handleClearCart();
                            case 7 -> {
                                username = getUsername();
                                role     = chooseRoleForLogin(username);
                                switchUser(username);
                            }
                            case 8 -> {
                                DataManager.saveUserRoles(userRoles);
                                DataManager.saveCarts(userCarts);
                                printGoodbyeBox();
                                running = false;
                            }
                            default -> System.out.println(
                                    Colors.RED + "Invalid choice. Please select 1-8." + Colors.RESET
                            );
                        }
                    }

                    default -> { // user
                        switch (choice) {
                            case 1 -> catalog.displayCatalog();
                            case 2 -> handleAddProduct();
                            case 3 -> handleRemoveProduct();
                            case 4 -> currentCart.displayCart();
                            case 5 -> userCheckoutFlow();
                            case 6 -> handleClearCart();
                            case 7 -> {
                                username = getUsername();
                                role     = chooseRoleForLogin(username);
                                switchUser(username);
                            }
                            case 8 -> {
                                DataManager.saveUserRoles(userRoles);
                                DataManager.saveCarts(userCarts);
                                printGoodbyeBox();
                                running = false;
                            }
                            default -> System.out.println(
                                    Colors.RED + "Invalid choice. Please select 1-8." + Colors.RESET
                            );
                        }
                    }
                }
            } catch (Exception e) {
                System.err.println(
                        Colors.RED + "An error occurred: " + e.getMessage() + Colors.RESET
                );
                e.printStackTrace(System.err);
            }
        }

        scanner.close();
    }

    public static void main(String[] args) {
        new OnlineShoppingApp().run();
    }
}
